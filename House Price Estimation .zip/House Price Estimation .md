```python
from google.colab import drive
drive.mount('/content/drive')
```

    Go to this URL in a browser: https://accounts.google.com/o/oauth2/auth?client_id=947318989803-6bn6qk8qdgf4n4g3pfee6491hc0brc4i.apps.googleusercontent.com&redirect_uri=urn%3aietf%3awg%3aoauth%3a2.0%3aoob&response_type=code&scope=email%20https%3a%2f%2fwww.googleapis.com%2fauth%2fdocs.test%20https%3a%2f%2fwww.googleapis.com%2fauth%2fdrive%20https%3a%2f%2fwww.googleapis.com%2fauth%2fdrive.photos.readonly%20https%3a%2f%2fwww.googleapis.com%2fauth%2fpeopleapi.readonly
    
    Enter your authorization code:
    ··········
    Mounted at /content/drive
    


```python
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
%matplotlib inline
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error,r2_score
from IPython.display import Image
import glob
import cv2
import seaborn as sns
# Encode text values to dummy variables(i.e. [1,0,0],[0,1,0],[0,0,1] for red,green,blue)
def encode_text_dummy(df, name):
    dummies = pd.get_dummies(df[name])
    for x in dummies.columns:
        dummy_name = "{}-{}".format(name, x)
        df[dummy_name] = dummies[x]
    df.drop(name, axis=1, inplace=True)

# Encode a numeric column as zscores
def encode_numeric_zscore(df, name, mean=None, sd=None):
    if mean is None:
        mean = df[name].mean()

    if sd is None:
        sd = df[name].std()

    df[name] = (df[name] - mean) / sd

    
def get_outliers_row_idecies(df, name, sd):
    outliers_row_indecies = df.index[(np.abs(df[name] - df[name].mean()) >= (sd * df[name].std()))]
    return outliers_row_indecies

# Regression chart.

def chart_regression(pred,y,sort=True):
    t = pd.DataFrame({'pred' : pred, 'y' : y.flatten()})
    if sort:
        t.sort_values(by=['y'],inplace=True)
    a = plt.plot(t['y'].tolist(),label='expected')
    b = plt.plot(t['pred'].tolist(),label='prediction')
    plt.ylabel('output')
    plt.legend()
    plt.show()
    

def read_images(path_images='drive/My Drive/Colab Notebooks/Houses Dataset/'):
    '''Loading images and creating Datafram'''
    
    img = pd.DataFrame()

    #Bathroom Image
    bathroom_images=[]
    for number in range(1, 536):
        for path in glob.glob(path_images + str(number) + "_bathroom.jpg"):
            if os.path.isfile(path):
                bathroom_images.append(path)

    img['Bathroom_img'] = bathroom_images
    
    #Bedroom Image
    bedroom_images=[]
    for number in range(1, 536):
        for path in glob.glob(path_images + str(number) + "_bedroom.jpg"):
            if os.path.isfile(path):
                bedroom_images.append(path)

    img['Bedroom_img'] = bedroom_images
    
    #FrontalImage
    frontal_images=[]
    for number in range(1, 536):
        for path in glob.glob(path_images + str(number) + "_frontal.jpg"):
            if os.path.isfile(path):
                frontal_images.append(path)

    img['Frontal_img'] = frontal_images
    
    #Kitchen Image
    kitchen_images=[]
    for number in range(1, 536):
        for path in glob.glob(path_images + str(number) + "_kitchen.jpg"):
            if os.path.isfile(path):
                kitchen_images.append(path)

    img['Kitchen_img'] = kitchen_images
    
    return img



def concate_images(img):
    images_output=[]
    for row_index,row in img.iterrows():
        inputImages=[]
        outputImage = np.zeros((128, 128, 3), dtype="uint8")
        image_temp1 = cv2.imread(row.Bathroom_img)
        image1 = cv2.resize(image_temp1, (64 , 64))

        image_temp2 = cv2.imread(row.Bedroom_img)
        image2 = cv2.resize(image_temp2, (64 , 64))

        image_temp3 = cv2.imread(row.Frontal_img)
        image3 = cv2.resize(image_temp3, (64 , 64))

        image_temp4 = cv2.imread(row.Kitchen_img)
        image4 = cv2.resize(image_temp4, (64 , 64))

        inputImages.append(image1)
        inputImages.append(image2)
        inputImages.append(image3)
        inputImages.append(image4)

        outputImage[0:64, 0:64] = inputImages[0]
        outputImage[0:64, 64:128] = inputImages[1]
        outputImage[64:128, 64:128] = inputImages[2]
        outputImage[64:128, 0:64] = inputImages[3]


        images_output.append(outputImage)
    return images_output
```

## Importing Dataset


```python
data_path = "/content/gdrive/My Drive/MS/CSC 215/Project-3/Houses Dataset/"
```


```python
file = os.path.join('drive/My Drive/Colab Notebooks/Houses Dataset/HousesInfo.txt')
```


```python
cols = ['Bedrooms', 'Bathrooms', 'Area', 'Zipcode', 'Price']
```


```python
data = pd.read_csv(file, sep=' ', header=None, names=cols, na_values=[None, 'NA', '-', ' '])
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bedrooms</th>
      <th>Bathrooms</th>
      <th>Area</th>
      <th>Zipcode</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>4.0</td>
      <td>4053</td>
      <td>85255</td>
      <td>869500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4</td>
      <td>3.0</td>
      <td>3343</td>
      <td>36372</td>
      <td>865200</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>4.0</td>
      <td>3923</td>
      <td>85266</td>
      <td>889000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5</td>
      <td>5.0</td>
      <td>4022</td>
      <td>85262</td>
      <td>910000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>4.0</td>
      <td>4116</td>
      <td>85266</td>
      <td>971226</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.shape
```




    (535, 5)




```python
data.isnull().sum()
```




    Bedrooms     0
    Bathrooms    0
    Area         0
    Zipcode      0
    Price        0
    dtype: int64



# Outliars checking


```python
sns.boxplot(x=data['Price'])

```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fcc144da400>




![png](output_11_1.png)


# Image Processing


```python
## Bathroom.jpg
new_images=[]
for number in range(1, 536):
    for path in glob.glob("drive/My Drive/Colab Notebooks/Houses Dataset/" + str(number) + "_bathroom.jpg"):
        if os.path.isfile(path):
            new_images.append(path)
```


```python
new_images
```




    ['drive/My Drive/Colab Notebooks/Houses Dataset/1_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/2_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/3_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/4_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/5_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/6_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/7_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/8_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/9_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/10_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/11_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/12_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/13_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/14_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/15_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/16_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/17_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/18_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/19_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/20_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/21_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/22_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/23_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/24_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/25_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/26_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/27_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/28_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/29_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/30_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/31_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/32_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/33_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/34_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/35_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/36_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/37_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/38_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/39_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/40_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/41_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/42_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/43_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/44_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/45_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/46_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/47_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/48_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/49_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/50_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/51_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/52_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/53_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/54_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/55_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/56_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/57_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/58_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/59_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/60_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/61_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/62_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/63_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/64_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/65_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/66_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/67_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/68_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/69_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/70_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/71_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/72_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/73_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/74_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/75_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/76_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/77_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/78_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/79_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/80_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/81_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/82_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/83_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/84_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/85_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/86_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/87_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/88_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/89_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/90_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/91_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/92_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/93_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/94_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/95_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/96_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/97_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/98_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/99_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/100_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/101_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/102_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/103_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/104_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/105_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/106_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/107_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/108_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/109_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/110_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/111_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/112_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/113_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/114_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/115_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/116_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/117_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/118_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/119_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/120_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/121_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/122_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/123_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/124_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/125_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/126_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/127_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/128_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/129_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/130_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/131_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/132_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/133_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/134_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/135_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/136_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/137_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/138_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/139_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/140_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/141_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/142_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/143_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/144_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/145_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/146_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/147_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/148_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/149_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/150_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/151_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/152_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/153_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/154_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/155_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/156_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/157_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/158_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/159_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/160_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/161_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/162_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/163_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/164_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/165_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/166_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/167_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/168_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/169_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/170_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/171_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/172_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/173_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/174_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/175_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/176_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/177_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/178_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/179_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/180_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/181_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/182_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/183_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/184_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/185_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/186_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/187_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/188_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/189_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/190_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/191_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/192_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/193_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/194_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/195_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/196_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/197_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/198_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/199_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/200_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/201_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/202_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/203_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/204_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/205_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/206_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/207_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/208_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/209_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/210_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/211_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/212_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/213_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/214_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/215_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/216_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/217_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/218_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/219_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/220_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/221_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/222_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/223_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/224_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/225_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/226_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/227_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/228_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/229_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/230_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/231_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/232_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/233_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/234_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/235_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/236_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/237_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/238_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/239_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/240_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/241_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/242_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/243_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/244_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/245_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/246_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/247_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/248_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/249_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/250_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/251_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/252_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/253_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/254_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/255_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/256_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/257_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/258_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/259_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/260_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/261_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/262_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/263_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/264_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/265_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/266_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/267_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/268_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/269_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/270_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/271_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/272_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/273_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/274_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/275_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/276_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/277_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/278_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/279_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/280_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/281_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/282_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/283_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/284_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/285_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/286_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/287_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/288_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/289_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/290_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/291_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/292_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/293_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/294_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/295_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/296_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/297_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/298_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/299_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/300_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/301_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/302_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/303_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/304_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/305_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/306_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/307_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/308_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/309_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/310_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/311_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/312_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/313_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/314_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/315_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/316_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/317_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/318_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/319_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/320_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/321_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/322_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/323_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/324_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/325_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/326_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/327_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/328_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/329_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/330_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/331_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/332_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/333_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/334_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/335_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/336_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/337_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/338_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/339_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/340_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/341_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/342_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/343_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/344_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/345_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/346_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/347_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/348_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/349_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/350_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/351_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/352_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/353_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/354_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/355_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/356_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/357_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/358_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/359_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/360_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/361_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/362_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/363_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/364_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/365_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/366_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/367_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/368_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/369_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/370_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/371_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/372_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/373_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/374_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/375_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/376_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/377_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/378_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/379_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/380_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/381_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/382_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/383_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/384_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/385_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/386_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/387_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/388_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/389_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/390_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/391_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/392_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/393_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/394_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/395_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/396_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/397_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/398_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/399_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/400_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/401_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/402_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/403_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/404_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/405_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/406_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/407_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/408_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/409_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/410_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/411_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/412_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/413_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/414_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/415_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/416_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/417_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/418_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/419_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/420_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/421_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/422_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/423_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/424_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/425_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/426_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/427_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/428_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/429_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/430_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/431_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/432_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/433_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/434_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/435_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/436_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/437_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/438_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/439_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/440_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/441_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/442_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/443_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/444_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/445_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/446_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/447_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/448_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/449_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/450_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/451_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/452_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/453_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/454_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/455_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/456_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/457_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/458_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/459_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/460_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/461_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/462_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/463_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/464_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/465_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/466_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/467_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/468_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/469_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/470_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/471_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/472_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/473_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/474_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/475_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/476_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/477_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/478_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/479_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/480_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/481_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/482_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/483_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/484_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/485_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/486_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/487_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/488_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/489_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/490_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/491_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/492_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/493_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/494_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/495_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/496_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/497_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/498_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/499_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/500_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/501_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/502_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/503_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/504_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/505_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/506_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/507_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/508_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/509_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/510_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/511_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/512_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/513_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/514_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/515_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/516_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/517_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/518_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/519_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/520_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/521_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/522_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/523_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/524_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/525_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/526_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/527_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/528_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/529_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/530_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/531_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/532_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/533_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/534_bathroom.jpg',
     'drive/My Drive/Colab Notebooks/Houses Dataset/535_bathroom.jpg']




```python
img= pd.DataFrame(new_images,columns = ['bathroom_img'])
```


```python
## bedroom images
bedroom_images = []
for number in range(1, 536):
    for path in glob.glob("drive/My Drive/Colab Notebooks/Houses Dataset/" + str(number) + "_bedroom.jpg"):
        if os.path.isfile(path):
            bedroom_images.append(path) 
            
img['bedroom_img']=bedroom_images
```


```python
img['bedroom_img']=bedroom_images
```


```python
frontal_images = []
for number in range(1, 536):
    for path in glob.glob("drive/My Drive/Colab Notebooks/Houses Dataset/" + str(number) + "_frontal.jpg"):
        if os.path.isfile(path):
            frontal_images.append(path) 

img['frontal_img']=frontal_images
```


```python
kitchen_images = []
for number in range(1, 536):
    for path in glob.glob("drive/My Drive/Colab Notebooks/Houses Dataset/" + str(number) + "_kitchen.jpg"):
        if os.path.isfile(path):
            kitchen_images.append(path) 

img['kitchen_img']=kitchen_images
```


```python
img.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>bathroom_img</th>
      <th>bedroom_img</th>
      <th>frontal_img</th>
      <th>kitchen_img</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
  </tbody>
</table>
</div>




```python
img.shape
```




    (535, 4)



# Combining text and visual data 


```python
final = pd.concat([data, img], axis=1, sort=False)
```


```python
final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bedrooms</th>
      <th>Bathrooms</th>
      <th>Area</th>
      <th>Zipcode</th>
      <th>Price</th>
      <th>bathroom_img</th>
      <th>bedroom_img</th>
      <th>frontal_img</th>
      <th>kitchen_img</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>4.0</td>
      <td>4053</td>
      <td>85255</td>
      <td>869500</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4</td>
      <td>3.0</td>
      <td>3343</td>
      <td>36372</td>
      <td>865200</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>4.0</td>
      <td>3923</td>
      <td>85266</td>
      <td>889000</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5</td>
      <td>5.0</td>
      <td>4022</td>
      <td>85262</td>
      <td>910000</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>4.0</td>
      <td>4116</td>
      <td>85266</td>
      <td>971226</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
  </tbody>
</table>
</div>




```python
result = final[final['Price'] >=100000] 
result = result[result['Price'] <=900000] 

result
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bedrooms</th>
      <th>Bathrooms</th>
      <th>Area</th>
      <th>Zipcode</th>
      <th>Price</th>
      <th>bathroom_img</th>
      <th>bedroom_img</th>
      <th>frontal_img</th>
      <th>kitchen_img</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>4.0</td>
      <td>4053</td>
      <td>85255</td>
      <td>869500</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4</td>
      <td>3.0</td>
      <td>3343</td>
      <td>36372</td>
      <td>865200</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>4.0</td>
      <td>3923</td>
      <td>85266</td>
      <td>889000</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3</td>
      <td>4.0</td>
      <td>2544</td>
      <td>85262</td>
      <td>799000</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>5</td>
      <td>5.0</td>
      <td>4829</td>
      <td>85266</td>
      <td>519200</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>530</th>
      <td>5</td>
      <td>2.0</td>
      <td>2066</td>
      <td>94531</td>
      <td>399900</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>531</th>
      <td>4</td>
      <td>3.5</td>
      <td>9536</td>
      <td>94531</td>
      <td>460000</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>532</th>
      <td>3</td>
      <td>2.0</td>
      <td>2014</td>
      <td>94531</td>
      <td>407000</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>533</th>
      <td>4</td>
      <td>3.0</td>
      <td>2312</td>
      <td>94531</td>
      <td>419000</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>534</th>
      <td>5</td>
      <td>3.0</td>
      <td>3796</td>
      <td>94531</td>
      <td>615000</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
  </tbody>
</table>
<p>406 rows × 9 columns</p>
</div>




```python
img = result.drop(columns =['Bedrooms',	'Bathrooms',	'Area',	'Zipcode',	'Price'], inplace = False) 
img.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>bathroom_img</th>
      <th>bedroom_img</th>
      <th>frontal_img</th>
      <th>kitchen_img</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
      <td>drive/My Drive/Colab Notebooks/Houses Dataset/...</td>
    </tr>
  </tbody>
</table>
</div>




```python
img.shape
```




    (406, 4)




```python
text = result.drop(columns =['bathroom_img',	'bedroom_img',	'frontal_img',	'kitchen_img'], inplace = False) 
text.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bedrooms</th>
      <th>Bathrooms</th>
      <th>Area</th>
      <th>Zipcode</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>4.0</td>
      <td>4053</td>
      <td>85255</td>
      <td>869500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4</td>
      <td>3.0</td>
      <td>3343</td>
      <td>36372</td>
      <td>865200</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>4.0</td>
      <td>3923</td>
      <td>85266</td>
      <td>889000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3</td>
      <td>4.0</td>
      <td>2544</td>
      <td>85262</td>
      <td>799000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>5</td>
      <td>5.0</td>
      <td>4829</td>
      <td>85266</td>
      <td>519200</td>
    </tr>
  </tbody>
</table>
</div>



# Combining text and visual data 


```python
images_output=[]
for row_index,row in img.iterrows():
            inputImages=[]
            outputImage = np.zeros((128, 128, 3), dtype="uint8")
            image_temp1 = cv2.imread(row.bathroom_img)
            image1 = cv2.resize(image_temp1, (64 , 64))
            
            image_temp2 = cv2.imread(row.bedroom_img)
            image2 = cv2.resize(image_temp2, (64 , 64))
            
            image_temp3 = cv2.imread(row.frontal_img)
            image3 = cv2.resize(image_temp3, (64 , 64))
            
            image_temp4 = cv2.imread(row.kitchen_img)
            image4 = cv2.resize(image_temp4, (64 , 64))
              
            inputImages.append(image1)
            inputImages.append(image2)
            inputImages.append(image3)
            inputImages.append(image4)
            
            outputImage[0:64, 0:64] = inputImages[0]
            outputImage[0:64, 64:128] = inputImages[1]
            outputImage[64:128, 64:128] = inputImages[2]
            outputImage[64:128, 0:64] = inputImages[3]
            
        
            images_output.append(outputImage)      
```


```python
for i in images_output:
     plt.figure(figsize=(8,8))
     plt.imshow(i, interpolation='nearest')
     plt.show()
```


![png](output_31_0.png)



![png](output_31_1.png)



![png](output_31_2.png)



![png](output_31_3.png)



![png](output_31_4.png)



![png](output_31_5.png)



![png](output_31_6.png)



![png](output_31_7.png)



![png](output_31_8.png)



![png](output_31_9.png)



![png](output_31_10.png)



![png](output_31_11.png)



![png](output_31_12.png)



![png](output_31_13.png)



![png](output_31_14.png)



![png](output_31_15.png)



![png](output_31_16.png)



![png](output_31_17.png)



![png](output_31_18.png)



![png](output_31_19.png)



![png](output_31_20.png)



![png](output_31_21.png)



![png](output_31_22.png)



![png](output_31_23.png)



![png](output_31_24.png)



![png](output_31_25.png)



![png](output_31_26.png)



![png](output_31_27.png)



![png](output_31_28.png)



![png](output_31_29.png)



![png](output_31_30.png)



![png](output_31_31.png)



![png](output_31_32.png)



![png](output_31_33.png)



![png](output_31_34.png)



![png](output_31_35.png)



![png](output_31_36.png)



![png](output_31_37.png)



![png](output_31_38.png)



![png](output_31_39.png)



![png](output_31_40.png)



![png](output_31_41.png)



![png](output_31_42.png)



![png](output_31_43.png)



![png](output_31_44.png)



![png](output_31_45.png)



![png](output_31_46.png)



![png](output_31_47.png)



![png](output_31_48.png)



![png](output_31_49.png)



![png](output_31_50.png)



![png](output_31_51.png)



![png](output_31_52.png)



![png](output_31_53.png)



![png](output_31_54.png)



![png](output_31_55.png)



![png](output_31_56.png)



![png](output_31_57.png)



![png](output_31_58.png)



![png](output_31_59.png)



![png](output_31_60.png)



![png](output_31_61.png)



![png](output_31_62.png)



![png](output_31_63.png)



![png](output_31_64.png)



![png](output_31_65.png)



![png](output_31_66.png)



![png](output_31_67.png)



![png](output_31_68.png)



![png](output_31_69.png)



![png](output_31_70.png)



![png](output_31_71.png)



![png](output_31_72.png)



![png](output_31_73.png)



![png](output_31_74.png)



![png](output_31_75.png)



![png](output_31_76.png)



![png](output_31_77.png)



![png](output_31_78.png)



![png](output_31_79.png)



![png](output_31_80.png)



![png](output_31_81.png)



![png](output_31_82.png)



![png](output_31_83.png)



![png](output_31_84.png)



![png](output_31_85.png)



![png](output_31_86.png)



![png](output_31_87.png)



![png](output_31_88.png)



![png](output_31_89.png)



![png](output_31_90.png)



![png](output_31_91.png)



![png](output_31_92.png)



![png](output_31_93.png)



![png](output_31_94.png)



![png](output_31_95.png)



![png](output_31_96.png)



![png](output_31_97.png)



![png](output_31_98.png)



![png](output_31_99.png)



![png](output_31_100.png)



![png](output_31_101.png)



![png](output_31_102.png)



![png](output_31_103.png)



![png](output_31_104.png)



![png](output_31_105.png)



![png](output_31_106.png)



![png](output_31_107.png)



![png](output_31_108.png)



![png](output_31_109.png)



![png](output_31_110.png)



![png](output_31_111.png)



![png](output_31_112.png)



![png](output_31_113.png)



![png](output_31_114.png)



![png](output_31_115.png)



![png](output_31_116.png)



![png](output_31_117.png)



![png](output_31_118.png)



![png](output_31_119.png)



![png](output_31_120.png)



![png](output_31_121.png)



![png](output_31_122.png)



![png](output_31_123.png)



![png](output_31_124.png)



![png](output_31_125.png)



![png](output_31_126.png)



![png](output_31_127.png)



![png](output_31_128.png)



![png](output_31_129.png)



![png](output_31_130.png)



![png](output_31_131.png)



![png](output_31_132.png)



![png](output_31_133.png)



![png](output_31_134.png)



![png](output_31_135.png)



![png](output_31_136.png)



![png](output_31_137.png)



![png](output_31_138.png)



![png](output_31_139.png)



![png](output_31_140.png)



![png](output_31_141.png)



![png](output_31_142.png)



![png](output_31_143.png)



![png](output_31_144.png)



![png](output_31_145.png)



![png](output_31_146.png)



![png](output_31_147.png)



![png](output_31_148.png)



![png](output_31_149.png)



![png](output_31_150.png)



![png](output_31_151.png)



![png](output_31_152.png)



![png](output_31_153.png)



![png](output_31_154.png)



![png](output_31_155.png)



![png](output_31_156.png)



![png](output_31_157.png)



![png](output_31_158.png)



![png](output_31_159.png)



![png](output_31_160.png)



![png](output_31_161.png)



![png](output_31_162.png)



![png](output_31_163.png)



![png](output_31_164.png)



![png](output_31_165.png)



![png](output_31_166.png)



![png](output_31_167.png)



![png](output_31_168.png)



![png](output_31_169.png)



![png](output_31_170.png)



![png](output_31_171.png)



![png](output_31_172.png)



![png](output_31_173.png)



![png](output_31_174.png)



![png](output_31_175.png)



![png](output_31_176.png)



![png](output_31_177.png)



![png](output_31_178.png)



![png](output_31_179.png)



![png](output_31_180.png)



![png](output_31_181.png)



![png](output_31_182.png)



![png](output_31_183.png)



![png](output_31_184.png)



![png](output_31_185.png)



![png](output_31_186.png)



![png](output_31_187.png)



![png](output_31_188.png)



![png](output_31_189.png)



![png](output_31_190.png)



![png](output_31_191.png)



![png](output_31_192.png)



![png](output_31_193.png)



![png](output_31_194.png)



![png](output_31_195.png)



![png](output_31_196.png)



![png](output_31_197.png)



![png](output_31_198.png)



![png](output_31_199.png)



![png](output_31_200.png)



![png](output_31_201.png)



![png](output_31_202.png)



![png](output_31_203.png)



![png](output_31_204.png)



![png](output_31_205.png)



![png](output_31_206.png)



![png](output_31_207.png)



![png](output_31_208.png)



![png](output_31_209.png)



![png](output_31_210.png)



![png](output_31_211.png)



![png](output_31_212.png)



![png](output_31_213.png)



![png](output_31_214.png)



![png](output_31_215.png)



![png](output_31_216.png)



![png](output_31_217.png)



![png](output_31_218.png)



![png](output_31_219.png)



![png](output_31_220.png)



![png](output_31_221.png)



![png](output_31_222.png)



![png](output_31_223.png)



![png](output_31_224.png)



![png](output_31_225.png)



![png](output_31_226.png)



![png](output_31_227.png)



![png](output_31_228.png)



![png](output_31_229.png)



![png](output_31_230.png)



![png](output_31_231.png)



![png](output_31_232.png)



![png](output_31_233.png)



![png](output_31_234.png)



![png](output_31_235.png)



![png](output_31_236.png)



![png](output_31_237.png)



![png](output_31_238.png)



![png](output_31_239.png)



![png](output_31_240.png)



![png](output_31_241.png)



![png](output_31_242.png)



![png](output_31_243.png)



![png](output_31_244.png)



![png](output_31_245.png)



![png](output_31_246.png)



![png](output_31_247.png)



![png](output_31_248.png)



![png](output_31_249.png)



![png](output_31_250.png)



![png](output_31_251.png)



![png](output_31_252.png)



![png](output_31_253.png)



![png](output_31_254.png)



![png](output_31_255.png)



![png](output_31_256.png)



![png](output_31_257.png)



![png](output_31_258.png)



![png](output_31_259.png)



![png](output_31_260.png)



![png](output_31_261.png)



![png](output_31_262.png)



![png](output_31_263.png)



![png](output_31_264.png)



![png](output_31_265.png)



![png](output_31_266.png)



![png](output_31_267.png)



![png](output_31_268.png)



![png](output_31_269.png)



![png](output_31_270.png)



![png](output_31_271.png)



![png](output_31_272.png)



![png](output_31_273.png)



![png](output_31_274.png)



![png](output_31_275.png)



![png](output_31_276.png)



![png](output_31_277.png)



![png](output_31_278.png)



![png](output_31_279.png)



![png](output_31_280.png)



![png](output_31_281.png)



![png](output_31_282.png)



![png](output_31_283.png)



![png](output_31_284.png)



![png](output_31_285.png)



![png](output_31_286.png)



![png](output_31_287.png)



![png](output_31_288.png)



![png](output_31_289.png)



![png](output_31_290.png)



![png](output_31_291.png)



![png](output_31_292.png)



![png](output_31_293.png)



![png](output_31_294.png)



![png](output_31_295.png)



![png](output_31_296.png)



![png](output_31_297.png)



![png](output_31_298.png)



![png](output_31_299.png)



![png](output_31_300.png)



![png](output_31_301.png)



![png](output_31_302.png)



![png](output_31_303.png)



![png](output_31_304.png)



![png](output_31_305.png)



![png](output_31_306.png)



![png](output_31_307.png)



![png](output_31_308.png)



![png](output_31_309.png)



![png](output_31_310.png)



![png](output_31_311.png)



![png](output_31_312.png)



![png](output_31_313.png)



![png](output_31_314.png)



![png](output_31_315.png)



![png](output_31_316.png)



![png](output_31_317.png)



![png](output_31_318.png)



![png](output_31_319.png)



![png](output_31_320.png)



![png](output_31_321.png)



![png](output_31_322.png)



![png](output_31_323.png)



![png](output_31_324.png)



![png](output_31_325.png)



![png](output_31_326.png)



![png](output_31_327.png)



![png](output_31_328.png)



![png](output_31_329.png)



![png](output_31_330.png)



![png](output_31_331.png)



![png](output_31_332.png)



![png](output_31_333.png)



![png](output_31_334.png)



![png](output_31_335.png)



![png](output_31_336.png)



![png](output_31_337.png)



![png](output_31_338.png)



![png](output_31_339.png)



![png](output_31_340.png)



![png](output_31_341.png)



![png](output_31_342.png)



![png](output_31_343.png)



![png](output_31_344.png)



![png](output_31_345.png)



![png](output_31_346.png)



![png](output_31_347.png)



![png](output_31_348.png)



![png](output_31_349.png)



![png](output_31_350.png)



![png](output_31_351.png)



![png](output_31_352.png)



![png](output_31_353.png)



![png](output_31_354.png)



![png](output_31_355.png)



![png](output_31_356.png)



![png](output_31_357.png)



![png](output_31_358.png)



![png](output_31_359.png)



![png](output_31_360.png)



![png](output_31_361.png)



![png](output_31_362.png)



![png](output_31_363.png)



![png](output_31_364.png)



![png](output_31_365.png)



![png](output_31_366.png)



![png](output_31_367.png)



![png](output_31_368.png)



![png](output_31_369.png)



![png](output_31_370.png)



![png](output_31_371.png)



![png](output_31_372.png)



![png](output_31_373.png)



![png](output_31_374.png)



![png](output_31_375.png)



![png](output_31_376.png)



![png](output_31_377.png)



![png](output_31_378.png)



![png](output_31_379.png)



![png](output_31_380.png)



![png](output_31_381.png)



![png](output_31_382.png)



![png](output_31_383.png)



![png](output_31_384.png)



![png](output_31_385.png)



![png](output_31_386.png)



![png](output_31_387.png)



![png](output_31_388.png)



![png](output_31_389.png)



![png](output_31_390.png)



![png](output_31_391.png)



![png](output_31_392.png)



![png](output_31_393.png)



![png](output_31_394.png)



![png](output_31_395.png)



![png](output_31_396.png)



![png](output_31_397.png)



![png](output_31_398.png)



![png](output_31_399.png)



![png](output_31_400.png)



![png](output_31_401.png)



![png](output_31_402.png)



![png](output_31_403.png)



![png](output_31_404.png)



![png](output_31_405.png)



```python
img_arr=np.asarray(images_output)
```


```python
img_arr.shape
```




    (406, 128, 128, 3)




```python
text.shape, img_arr.shape
```




    ((406, 5), (406, 128, 128, 3))




```python
text_y = pd.DataFrame()
text_y['Price'] = text['Price']
```


```python
text_x = text.drop(columns=['Price'], inplace=False)
```


```python
text_x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bedrooms</th>
      <th>Bathrooms</th>
      <th>Area</th>
      <th>Zipcode</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>4.0</td>
      <td>4053</td>
      <td>85255</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4</td>
      <td>3.0</td>
      <td>3343</td>
      <td>36372</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>4.0</td>
      <td>3923</td>
      <td>85266</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3</td>
      <td>4.0</td>
      <td>2544</td>
      <td>85262</td>
    </tr>
    <tr>
      <th>10</th>
      <td>5</td>
      <td>5.0</td>
      <td>4829</td>
      <td>85266</td>
    </tr>
  </tbody>
</table>
</div>




```python
text_y.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>869500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>865200</td>
    </tr>
    <tr>
      <th>2</th>
      <td>889000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>799000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>519200</td>
    </tr>
  </tbody>
</table>
</div>




```python
encode_numeric_zscore(text_x,'Area')
```


```python
text_x.shape
```




    (406, 4)




```python
encode_text_dummy(text_x,'Bedrooms')
encode_text_dummy(text_x,'Bathrooms')
encode_text_dummy(text_x,'Zipcode')
```


```python
text_x.shape
```




    (406, 61)




```python
text_x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Area</th>
      <th>Bedrooms-1</th>
      <th>Bedrooms-2</th>
      <th>Bedrooms-3</th>
      <th>Bedrooms-4</th>
      <th>Bedrooms-5</th>
      <th>Bedrooms-6</th>
      <th>Bedrooms-7</th>
      <th>Bedrooms-8</th>
      <th>Bedrooms-10</th>
      <th>Bathrooms-1.0</th>
      <th>Bathrooms-1.5</th>
      <th>Bathrooms-2.0</th>
      <th>Bathrooms-2.5</th>
      <th>Bathrooms-3.0</th>
      <th>Bathrooms-3.25</th>
      <th>Bathrooms-3.5</th>
      <th>Bathrooms-4.0</th>
      <th>Bathrooms-4.5</th>
      <th>Bathrooms-5.0</th>
      <th>Bathrooms-6.0</th>
      <th>Zipcode-36372</th>
      <th>Zipcode-60002</th>
      <th>Zipcode-60016</th>
      <th>Zipcode-60046</th>
      <th>Zipcode-62025</th>
      <th>Zipcode-62034</th>
      <th>Zipcode-62088</th>
      <th>Zipcode-62214</th>
      <th>Zipcode-62234</th>
      <th>Zipcode-62249</th>
      <th>Zipcode-81418</th>
      <th>Zipcode-81521</th>
      <th>Zipcode-81524</th>
      <th>Zipcode-85255</th>
      <th>Zipcode-85262</th>
      <th>Zipcode-85266</th>
      <th>Zipcode-85331</th>
      <th>Zipcode-91752</th>
      <th>Zipcode-91901</th>
      <th>Zipcode-91915</th>
      <th>Zipcode-92021</th>
      <th>Zipcode-92253</th>
      <th>Zipcode-92276</th>
      <th>Zipcode-92543</th>
      <th>Zipcode-92677</th>
      <th>Zipcode-92692</th>
      <th>Zipcode-92802</th>
      <th>Zipcode-92880</th>
      <th>Zipcode-93105</th>
      <th>Zipcode-93111</th>
      <th>Zipcode-93314</th>
      <th>Zipcode-93446</th>
      <th>Zipcode-93510</th>
      <th>Zipcode-94501</th>
      <th>Zipcode-94531</th>
      <th>Zipcode-94565</th>
      <th>Zipcode-94568</th>
      <th>Zipcode-95220</th>
      <th>Zipcode-96019</th>
      <th>Zipcode-98021</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.541416</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.918549</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.427370</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.217604</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2.222184</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



#split


```python
x_train, x_test, y_train, y_test = train_test_split(text_x, text_y, test_size=0.3, random_state=42)
```


```python
img_train, img_test = train_test_split(img_arr, test_size=0.3, shuffle=False, stratify=None)
```


```python
print(x_train.shape)
print(y_train.shape)
print(x_test.shape)
print(y_test.shape)
print(img_train.shape)
print(img_test.shape)
```

    (284, 61)
    (284, 1)
    (122, 61)
    (122, 1)
    (284, 128, 128, 3)
    (122, 128, 128, 3)
    

# Keras functional API


```python
# Multiple Inputs
from sklearn import metrics
from keras.utils import plot_model
from keras.models import Model, Sequential
from keras.layers import Input, Dense, Flatten, Activation, Dropout
from keras.layers.convolutional import Conv2D
from keras.layers.pooling import MaxPooling2D
from keras.layers.merge import concatenate
from keras.callbacks import EarlyStopping
from keras.callbacks import ModelCheckpoint

#Model1
model1 = Sequential()
model1.add(Dense(512, input_dim=x_train.shape[1], activation="relu"))
model1.add(Dense(256,activation="relu"))
model1.add(Dense(128,activation="relu"))
model1.add(Dense(64,activation="relu"))
model1.add(Dense(32,activation="relu"))
model1.add(Dense(1))

#Model2
visible2 = Input(shape=(128,128,3))
conv1 = Conv2D(64, kernel_size=4, activation='relu')(visible2)
pool1 = MaxPooling2D(pool_size=(2, 2))(conv1)
conv2 = Conv2D(32, kernel_size=3, activation='relu')(pool1)
pool2 = MaxPooling2D(pool_size=(2, 2))(conv2)
conv3 = Conv2D(16, kernel_size=4, activation='relu')(pool2)
pool3 = MaxPooling2D(pool_size=(2, 2))(conv3)
conv4 = Conv2D(16, kernel_size=4, activation='relu')(pool3)
pool4 = MaxPooling2D(pool_size=(2, 2))(conv4)
flat = Flatten()(pool4)


#Merging
merge = concatenate([model1.output, flat])

hidden1 = Dense(10, activation='relu')(merge)
hidden2 = Dense(10, activation='relu')(hidden1)
output = Dense(1, activation="relu")(hidden2)

model = Model(inputs=[model1.input, visible2], outputs=output)

print(model.summary())

plot_model(model,)
```

    Model: "model_3"
    __________________________________________________________________________________________________
    Layer (type)                    Output Shape         Param #     Connected to                     
    ==================================================================================================
    input_3 (InputLayer)            (None, 128, 128, 3)  0                                            
    __________________________________________________________________________________________________
    conv2d_9 (Conv2D)               (None, 125, 125, 64) 3136        input_3[0][0]                    
    __________________________________________________________________________________________________
    max_pooling2d_9 (MaxPooling2D)  (None, 62, 62, 64)   0           conv2d_9[0][0]                   
    __________________________________________________________________________________________________
    dense_19_input (InputLayer)     (None, 61)           0                                            
    __________________________________________________________________________________________________
    conv2d_10 (Conv2D)              (None, 60, 60, 32)   18464       max_pooling2d_9[0][0]            
    __________________________________________________________________________________________________
    dense_19 (Dense)                (None, 512)          31744       dense_19_input[0][0]             
    __________________________________________________________________________________________________
    max_pooling2d_10 (MaxPooling2D) (None, 30, 30, 32)   0           conv2d_10[0][0]                  
    __________________________________________________________________________________________________
    dense_20 (Dense)                (None, 256)          131328      dense_19[0][0]                   
    __________________________________________________________________________________________________
    conv2d_11 (Conv2D)              (None, 27, 27, 16)   8208        max_pooling2d_10[0][0]           
    __________________________________________________________________________________________________
    dense_21 (Dense)                (None, 128)          32896       dense_20[0][0]                   
    __________________________________________________________________________________________________
    max_pooling2d_11 (MaxPooling2D) (None, 13, 13, 16)   0           conv2d_11[0][0]                  
    __________________________________________________________________________________________________
    dense_22 (Dense)                (None, 64)           8256        dense_21[0][0]                   
    __________________________________________________________________________________________________
    conv2d_12 (Conv2D)              (None, 10, 10, 16)   4112        max_pooling2d_11[0][0]           
    __________________________________________________________________________________________________
    dense_23 (Dense)                (None, 32)           2080        dense_22[0][0]                   
    __________________________________________________________________________________________________
    max_pooling2d_12 (MaxPooling2D) (None, 5, 5, 16)     0           conv2d_12[0][0]                  
    __________________________________________________________________________________________________
    dense_24 (Dense)                (None, 1)            33          dense_23[0][0]                   
    __________________________________________________________________________________________________
    flatten_3 (Flatten)             (None, 400)          0           max_pooling2d_12[0][0]           
    __________________________________________________________________________________________________
    concatenate_3 (Concatenate)     (None, 401)          0           dense_24[0][0]                   
                                                                     flatten_3[0][0]                  
    __________________________________________________________________________________________________
    dense_25 (Dense)                (None, 10)           4020        concatenate_3[0][0]              
    __________________________________________________________________________________________________
    dense_26 (Dense)                (None, 10)           110         dense_25[0][0]                   
    __________________________________________________________________________________________________
    dense_27 (Dense)                (None, 1)            11          dense_26[0][0]                   
    ==================================================================================================
    Total params: 244,398
    Trainable params: 244,398
    Non-trainable params: 0
    __________________________________________________________________________________________________
    None
    




![png](output_49_1.png)




```python
model.compile(loss="mean_squared_error", optimizer='adam')

monitor = EarlyStopping(monitor='val_loss', min_delta=1e-3, patience=5, verbose=1, mode='auto')
checkpointer = ModelCheckpoint(filepath="best_weights.hdf5", verbose=0, save_best_only=True) # save best model
model.fit([x_train,img_train], y_train, validation_data= ([x_test, img_test], y_test), callbacks=[monitor,checkpointer],verbose=2,epochs=200)
model.load_weights('best_weights.hdf5') # load weights from best model
```

    Train on 284 samples, validate on 122 samples
    Epoch 1/200
     - 1s - loss: 280456249574.7606 - val_loss: 278073968203.5410
    Epoch 2/200
     - 0s - loss: 250335444761.2394 - val_loss: 176727262526.9508
    Epoch 3/200
     - 0s - loss: 103086049885.7465 - val_loss: 70821043955.4098
    Epoch 4/200
     - 0s - loss: 61172182809.2394 - val_loss: 69647658672.2623
    Epoch 5/200
     - 0s - loss: 59474875464.1127 - val_loss: 51515977795.1475
    Epoch 6/200
     - 0s - loss: 53976180995.6056 - val_loss: 49264308962.6229
    Epoch 7/200
     - 0s - loss: 52720689036.6197 - val_loss: 47196869078.0328
    Epoch 8/200
     - 0s - loss: 51846787879.6620 - val_loss: 47931188744.3934
    Epoch 9/200
     - 0s - loss: 53825757472.4507 - val_loss: 47663521724.8525
    Epoch 10/200
     - 0s - loss: 52715920658.0282 - val_loss: 48348320482.6229
    Epoch 11/200
     - 0s - loss: 51918646199.8873 - val_loss: 47067486980.1967
    Epoch 12/200
     - 0s - loss: 51262471845.8592 - val_loss: 46571553439.4754
    Epoch 13/200
     - 0s - loss: 49320491498.3662 - val_loss: 45369945104.7869
    Epoch 14/200
     - 0s - loss: 47812103211.2676 - val_loss: 43370276696.1311
    Epoch 15/200
     - 0s - loss: 44767360245.1831 - val_loss: 38925141243.8033
    Epoch 16/200
     - 0s - loss: 40720560070.3099 - val_loss: 35429730774.0328
    Epoch 17/200
     - 0s - loss: 35862816162.2535 - val_loss: 30145703264.5246
    Epoch 18/200
     - 0s - loss: 31868082233.6901 - val_loss: 26994457616.7869
    Epoch 19/200
     - 0s - loss: 27231892782.8732 - val_loss: 24295192257.0492
    Epoch 20/200
     - 0s - loss: 24163082369.8028 - val_loss: 21616333454.6885
    Epoch 21/200
     - 0s - loss: 21596148577.3521 - val_loss: 19496995369.9672
    Epoch 22/200
     - 0s - loss: 19705528031.5493 - val_loss: 18099506075.2787
    Epoch 23/200
     - 0s - loss: 17187000579.6056 - val_loss: 16224742433.5738
    Epoch 24/200
     - 0s - loss: 15268846116.0563 - val_loss: 15122993991.3443
    Epoch 25/200
     - 0s - loss: 14089124092.3944 - val_loss: 15923343074.6230
    Epoch 26/200
     - 0s - loss: 13510868689.1268 - val_loss: 13789892843.0164
    Epoch 27/200
     - 0s - loss: 12174801097.9155 - val_loss: 14358010611.4098
    Epoch 28/200
     - 0s - loss: 11427461624.7887 - val_loss: 13783757530.2295
    Epoch 29/200
     - 0s - loss: 10898576629.1831 - val_loss: 14049245469.3770
    Epoch 30/200
     - 0s - loss: 10319590702.8732 - val_loss: 13473016764.8525
    Epoch 31/200
     - 0s - loss: 10378433189.8592 - val_loss: 13299429627.8033
    Epoch 32/200
     - 0s - loss: 9897582260.2817 - val_loss: 13623800001.0492
    Epoch 33/200
     - 0s - loss: 9358477849.2394 - val_loss: 13148705363.9344
    Epoch 34/200
     - 0s - loss: 9205331290.1408 - val_loss: 13697012098.0984
    Epoch 35/200
     - 0s - loss: 9026640744.5634 - val_loss: 13038118744.1311
    Epoch 36/200
     - 0s - loss: 8803603931.9437 - val_loss: 12752934970.7541
    Epoch 37/200
     - 0s - loss: 8486815844.9577 - val_loss: 13431677574.2951
    Epoch 38/200
     - 0s - loss: 8653130946.7042 - val_loss: 12475885920.5246
    Epoch 39/200
     - 0s - loss: 8309960336.2254 - val_loss: 12839426769.8361
    Epoch 40/200
     - 0s - loss: 7832667828.2817 - val_loss: 12454489381.7705
    Epoch 41/200
     - 0s - loss: 8100537819.9437 - val_loss: 13712816992.5246
    Epoch 42/200
     - 0s - loss: 7771566829.9718 - val_loss: 12353012819.9344
    Epoch 43/200
     - 0s - loss: 7444835104.4507 - val_loss: 13274072408.1311
    Epoch 44/200
     - 0s - loss: 7649759051.7183 - val_loss: 12584872724.9836
    Epoch 45/200
     - 0s - loss: 7253037337.2394 - val_loss: 12440991190.0328
    Epoch 46/200
     - 0s - loss: 7198867095.4366 - val_loss: 12378132001.5738
    Epoch 47/200
     - 0s - loss: 7193465033.9155 - val_loss: 12173729640.9180
    Epoch 48/200
     - 0s - loss: 7474944028.8451 - val_loss: 12840514627.1475
    Epoch 49/200
     - 0s - loss: 7029021811.3803 - val_loss: 12189163008.0000
    Epoch 50/200
     - 0s - loss: 6836449290.8169 - val_loss: 13129187739.2787
    Epoch 51/200
     - 0s - loss: 6807686450.4789 - val_loss: 12171330492.8525
    Epoch 52/200
     - 0s - loss: 6858768600.3380 - val_loss: 12877859269.2459
    Epoch 53/200
     - 0s - loss: 7072559882.8169 - val_loss: 12917890518.0328
    Epoch 54/200
     - 0s - loss: 6883796350.1972 - val_loss: 12193646717.9016
    Epoch 55/200
     - 0s - loss: 7009257118.6479 - val_loss: 12213916092.8525
    Epoch 56/200
     - 0s - loss: 6602722390.5352 - val_loss: 12326416702.9508
    Epoch 00056: early stopping
    


```python
pred = model.predict([x_test, img_test])
rmse = np.sqrt(metrics.mean_squared_error(pred,y_test))
print("Score (RMSE): {}".format(rmse))

#regression lift Chart
chart_regression(pred.flatten(), y_test.to_numpy(), sort=True)
```

    Score (RMSE): 110323.75148492663
    


![png](output_51_1.png)



```python

```
